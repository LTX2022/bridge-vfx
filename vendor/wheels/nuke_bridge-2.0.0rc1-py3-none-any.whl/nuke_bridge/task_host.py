"""Trusted controller launch/reconnect/stop for a task-owned Nuke TCP host."""
from __future__ import annotations
import errno
import hashlib
import json
import os
from pathlib import Path
import secrets
import sys
import time
import uuid
from dcc_task_runtime import owned_process
from dcc_task_runtime.platform_support import atomic_write, ensure_private_directory
from .client import NukeClient


def _file(value):
    path=Path(value).expanduser()
    if path.is_symlink() or not path.is_file(): raise ValueError('regular file required: '+str(path))
    return path.resolve()


def _write(path,payload):
    atomic_write(path,json.dumps(payload,sort_keys=True).encode('utf-8'),owned_root=path.parent)


def start(*, task_id, task_root, nuke_executable, addon_path, supervisor_executable,
          version='17.0v1', process_generation=1, snapshot=None, budget_seconds=120,
          software_api=False, software_api_dir=None, resource_budget=None, ledger_root=None, scheduler_root=None):
    """Only the trusted controller may call this with executable/config paths.

    Software mode is explicit and changes only the launch/native API boundary.
    Production always invokes Nuke -t and never falls back to Python or fake.
    """
    if not task_id or version!='17.0v1' or type(process_generation) is not int or process_generation<1:
        raise ValueError('invalid task/version/generation')
    executable=_file(nuke_executable);addon=_file(addon_path);supervisor=_file(supervisor_executable)
    if not os.access(executable,os.X_OK) or not os.access(supervisor,os.X_OK): raise ValueError('executable permission required')
    if software_api_dir is not None and software_api is not True: raise ValueError('software API injection is test-only')
    root=Path(task_root).expanduser().resolve();root.mkdir(parents=True,exist_ok=True)
    snapshot_path=None
    if snapshot is not None:
        snapshot_path=_file(snapshot)
        if not snapshot_path.is_relative_to(root) or snapshot_path.suffix.lower()!='.nk': raise ValueError('snapshot outside task root')
    nonce=uuid.uuid4().hex;work=ensure_private_directory(root/('nuke-host-'+nonce))
    identity={'task_id':str(task_id),'session_id':uuid.uuid4().hex,'launch_nonce':nonce,
              'process_generation':process_generation,'plugin_build':hashlib.sha256(addon.read_bytes()).hexdigest()}
    package=Path(__file__).resolve().parent
    config={'identity':identity,'task_root':str(root),'version':version,'nuke_executable':str(executable),'supervisor_executable':str(supervisor),
            'addon_path':str(addon),'render_worker':str(package/'owned_render_worker.py'),
            'software_api':software_api is True,'resource_budget':resource_budget,'snapshot':str(snapshot_path) if snapshot_path else None,
            'ready':str(work/'ready.json'),'token':secrets.token_urlsafe(32),
            'evidence_source':'software_test' if software_api is True else 'native_host'}
    _write(work/'launch.json',config)
    import dcc_task_runtime
    paths=[str(package.parent),str(Path(dcc_task_runtime.__file__).resolve().parent.parent)]
    if software_api is True:
        if not software_api_dir or not (Path(software_api_dir)/'nuke.py').is_file(): raise ValueError('explicit software API directory required')
        paths.insert(0,str(Path(software_api_dir).resolve()))
    env=dict(os.environ,PYTHONPATH=os.pathsep.join(dict.fromkeys(paths)),PYTHONNOUSERSITE='1',
             NUKE_BRIDGE_INSTANCES_DIR=str(work/'instances'),BRIDGE_SKILLS_STATE_ROOT=str(root/'state'))
    if ledger_root is not None: env['BRIDGE_ARTIFACT_LEDGER_ROOT']=str(Path(ledger_root).resolve())
    if scheduler_root is not None: env['BRIDGE_SKILLS_SCHEDULER_ROOT']=str(Path(scheduler_root).resolve())
    command=[str(executable)]+([] if software_api else ['-t'])+[str(package/'task_host_worker.py'),str(work/'launch.json')]
    handle=owned_process.launch(command,directory=work/'supervisor',identity=identity,
        supervisor_executable=str(supervisor),env=env,budget_seconds=budget_seconds,resource_budget=resource_budget)
    deadline=time.monotonic()+min(10,budget_seconds)
    ready_error=None
    try:
        while time.monotonic()<deadline:
            if handle.poll() is not None:
                error=(work/'worker-error.log').read_text() if (work/'worker-error.log').exists() else 'no worker error receipt'
                raise RuntimeError('task host exited before ready: '+error)
            if (work/'ready.json').is_file():
                try:
                    ready=json.loads((work/'ready.json').read_text(encoding='utf-8'))
                except OSError as exc:
                    if os.name!='nt' or not (getattr(exc,'winerror',None) in (5,32,33)
                            or isinstance(exc,PermissionError) and exc.errno==errno.EACCES):
                        raise
                    ready_error=exc
                    time.sleep(.01)
                    continue
                expected=dict(identity,pid=handle.pid,scene_epoch=1,version=version)
                if ready.get('task_host_identity')!=expected: raise ValueError('ready identity mismatch')
                client=NukeClient(ready['port'],token=config['token'])
                health=client.health()
                if health.get('task_host_identity')!=expected: raise ValueError('handshake identity mismatch')
                receipt={'work_dir':str(work),'port':ready['port'],'token':config['token'],
                         'expected_identity':expected,'evidence_source':config['evidence_source'],
                         'supervisor_identity':identity,'supervisor_dir':str(work/'supervisor')}
                _write(work/'host.json',receipt)
                return receipt
            time.sleep(.01)
        if ready_error is not None:
            raise RuntimeError('task host ready unreadable') from ready_error
        raise RuntimeError('task host ready timeout')
    except BaseException:
        handle.terminate()
        try: handle.wait(timeout=4)
        except Exception: pass
        raise


def reconnect(work_dir):
    work=Path(work_dir).resolve()
    if (work/'host.json').is_file():
        receipt=json.loads((work/'host.json').read_text())
    else:
        # Recover the launch->ready->controller-receipt interruption window
        # from the durable launch intent and supervisor-observed child PID.
        config=json.loads((work/'launch.json').read_text())
        ready=json.loads((work/'ready.json').read_text())
        observed=owned_process.OwnedProcessHandle(work/'supervisor',config['identity'])
        expected=dict(config['identity'],pid=observed.pid,scene_epoch=1,version=config['version'])
        if ready.get('task_host_identity')!=expected: raise ValueError('recovery ready identity mismatch')
        receipt={'work_dir':str(work),'port':ready['port'],'token':config['token'],
                 'expected_identity':expected,'evidence_source':config['evidence_source'],
                 'supervisor_identity':config['identity'],'supervisor_dir':str(work/'supervisor')}
    handle=owned_process.OwnedProcessHandle(work/'supervisor',receipt['supervisor_identity'])
    if handle.poll() is not None: raise RuntimeError('owned host is stopped')
    health=NukeClient(receipt['port'],token=receipt['token']).health()
    if health.get('task_host_identity')!=receipt['expected_identity']: raise ValueError('host identity/scene epoch changed')
    _write(work/'host.json',receipt)
    return receipt


def stop(work_dir, *, timeout=5):
    work=Path(work_dir).resolve();config=json.loads((work/'launch.json').read_text())
    handle=owned_process.OwnedProcessHandle(work/'supervisor',config['identity'])
    if handle.poll() is None: handle.terminate()
    try: handle.wait(timeout=timeout)
    except Exception:
        return {'stopped':False,'status':'STOP_UNKNOWN','work_dir':str(work)}
    return {'stopped':True,'status':'STOP_CONFIRMED','receipt':handle.receipt(),'work_dir':str(work)}

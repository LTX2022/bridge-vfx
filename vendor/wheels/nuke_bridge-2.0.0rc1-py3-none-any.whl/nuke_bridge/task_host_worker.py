"""Fixed task-owned headless Nuke control host, native calls on script main thread."""
from __future__ import annotations
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import queue
import sys
import threading


def run(config_path):
    config=json.loads(Path(config_path).read_text())
    import nuke
    plugin=Path(config['addon_path'])
    digest=hashlib.sha256(plugin.read_bytes()).hexdigest()
    if digest != config['identity']['plugin_build']: raise ValueError('plugin build changed')
    spec=importlib.util.spec_from_file_location('nuke_bridge_addon',plugin)
    addon=importlib.util.module_from_spec(spec);sys.modules[spec.name]=addon;spec.loader.exec_module(addon)
    pending=queue.Queue()
    # _run_main owns the timeout/cancellation fence; callbacks are queued, and
    # only this script's main thread invokes them. No GUI event loop is needed.
    addon._TASK_HOST_EXECUTOR=pending.put
    if config.get('snapshot'):
        nuke.scriptOpen(config['snapshot'])
    else:
        nuke.scriptClear()
    for name,kind in [('Read1','Read'),('Write1','Write')]:
        node=nuke.toNode(name)
        if node is None:
            node=nuke.createNode(kind,inpanel=False);node.setName(name)
        if node.Class()!=kind: raise ValueError('task node has wrong class: '+name)
    identity=dict(config['identity'],pid=os.getpid(),scene_epoch=1,version=str(nuke.NUKE_VERSION_STRING))
    addon._TASK_HOST_IDENTITY=identity
    addon._TASK_HOST_ROOT=Path(config['task_root']).resolve()
    def scene_changed(): identity['scene_epoch']+=1
    nuke.addOnScriptLoad(scene_changed)
    nuke.addOnScriptClose(scene_changed)
    addon.configure_nuke_background_route(nuke_executable=config['nuke_executable'],
        worker_script=config['render_worker'],software_api=config['software_api'],
        supervisor_executable=config['supervisor_executable'],resource_budget=config.get('resource_budget'))
    server=addon.NukeBridgeServer(token=config['token']);server.session_id=identity['session_id'];addon._SERVER=server
    port=server.start()
    from dcc_task_runtime.platform_support import atomic_write
    ready=Path(config['ready'])
    atomic_write(ready,json.dumps({'port':port,'task_host_identity':identity,'evidence_source':config['evidence_source']})
                 .encode('utf-8'),owned_root=ready.parent)
    try:
        while True:
            callback=pending.get()
            try: callback()
            except BaseException:
                # _run_main captures callback failures and returns them over
                # TCP. Keep this main loop available for the next request.
                pass
    finally: server.stop()

if __name__=='__main__':
    try: run(sys.argv[1])
    except BaseException:
        import traceback
        Path(sys.argv[1]).with_name('worker-error.log').write_text(traceback.format_exc())
        raise

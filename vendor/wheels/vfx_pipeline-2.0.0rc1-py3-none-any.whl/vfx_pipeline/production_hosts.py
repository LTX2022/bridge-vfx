"""Trusted deployment lifecycle for the formal WorkBuddy host boundaries.

Only the controller calls this module. Model tools receive bound transports,
never executable paths, lifecycle configuration or supervisor capabilities.
"""
from __future__ import annotations
import argparse
import contextlib
import hashlib
import io
import json
import math
import os
from pathlib import Path
import sys
from dcc_task_runtime.owned_process import OwnedProcessHandle
from dcc_task_runtime.platform_support import (lock_file, unlock_file, atomic_write,
    atomic_replace, remove_owned_path, ensure_private_directory, open_private_file)


def _atomic(path,value):
    ensure_private_directory(path.parent)
    atomic_write(path,json.dumps(value,sort_keys=True).encode('utf-8'),owned_root=path.parent)


@contextlib.contextmanager
def _deployment_lock(control):
    ensure_private_directory(control)
    fd=open_private_file(control/'production-hosts.lock',os.O_CREAT|os.O_RDWR)
    acquired=False
    try:
        lock_file(fd,blocking=True)
        acquired=True
        yield
    finally:
        try:
            if acquired:unlock_file(fd)
        finally:
            os.close(fd)


def _validate(raw,kind,controller_root,repo_root,allow_software):
    if not isinstance(raw,dict) or raw.get('lifecycle')!='task_owned':raise ValueError('PRODUCTION_TASK_OWNED_CONFIG_REQUIRED:'+kind)
    if raw.get('application')!=kind:raise ValueError('PRODUCTION_APPLICATION_MISMATCH')
    if raw.get('version') not in ({'21.0.631','22.0.429','22.0.459'} if kind=='houdini' else {'17.0v1'}):raise ValueError('PRODUCTION_VERSION_REQUIRED')
    for key in ('executable','supervisor_executable'):
        path=Path(str(raw.get(key) or '')).expanduser()
        if not path.is_absolute() or path.is_symlink() or not path.is_file() or not os.access(path,os.X_OK):raise ValueError('PRODUCTION_EXECUTABLE_UNVERIFIED:'+key)
    task_root=Path(str(raw.get('task_root') or '')).expanduser()
    if not task_root.is_absolute() or task_root.is_symlink():raise ValueError('PRODUCTION_TASK_ROOT_INVALID')
    task_root=task_root.resolve()
    if not controller_root.is_relative_to(task_root):raise ValueError('PRODUCTION_CONTROLLER_OUTSIDE_BUDGET_ROOT')
    budget=raw.get('resource_budget',{})
    if type(budget.get('max_bytes')) is not int or budget['max_bytes']<=0:raise ValueError('PRODUCTION_DISK_BUDGET_REQUIRED')
    roots=budget.get('roots')
    if not isinstance(roots,list) or not roots:raise ValueError('PRODUCTION_RESOURCE_ROOT_REQUIRED')
    paths=[]
    for name in roots:
        p=Path(name)
        if not p.is_absolute() or p.is_symlink() or not p.resolve().is_relative_to(task_root):raise ValueError('PRODUCTION_RESOURCE_ROOT_INVALID')
        paths.append(p.resolve())
    if not any(task_root==p for p in paths):raise ValueError('PRODUCTION_BUDGET_MUST_COVER_TASK_ROOT')
    seconds=raw.get('session_seconds')
    if type(seconds) not in (float,int) or not math.isfinite(seconds) or not 0<seconds<=120:raise ValueError('PRODUCTION_SESSION_BUDGET_REQUIRED')
    software=raw.get('evidence_source')=='software_test'
    if raw.get('evidence_source') not in ('software_test','real_host'):raise ValueError('PRODUCTION_EVIDENCE_SOURCE_REQUIRED')
    if software and allow_software is not True:raise ValueError('SOFTWARE_PROCESS_BOUNDARY_NOT_AUTHORIZED')
    if not software and 'software_api_dir' in raw:raise ValueError('SOFTWARE_API_IN_PRODUCTION')
    if not software and 'software_launch_script' in raw:raise ValueError('SOFTWARE_LAUNCH_IN_PRODUCTION')
    launch_config={}
    if 'software_launch_script' in raw:
        if kind!='houdini':raise ValueError('PRODUCTION_SOFTWARE_LAUNCH_UNSUPPORTED:'+kind)
        script=Path(str(raw['software_launch_script'] or ''))
        if not script.is_absolute() or script.is_symlink() or not script.is_file():
            raise ValueError('PRODUCTION_SOFTWARE_LAUNCH_SCRIPT_INVALID')
        digest=hashlib.sha256(script.read_bytes()).hexdigest()
        if ('software_launch_script_sha256' in raw
                and raw['software_launch_script_sha256']!=digest):
            raise ValueError('PRODUCTION_SOFTWARE_LAUNCH_SCRIPT_CHANGED')
        launch_config={'software_launch_script':str(script.resolve()),'software_launch_script_sha256':digest}
    plugin=repo_root/'plugins'/kind/('_impl/houdini_bridge_addon.py' if kind=='houdini' else 'nuke_bridge_addon.py')
    if not plugin.is_file():raise ValueError('BUNDLED_PLUGIN_MISSING')
    return {**raw,**launch_config,'task_root':str(task_root),'controller_root':str(controller_root.resolve()),
            'plugin_build':hashlib.sha256(plugin.read_bytes()).hexdigest(),
            'resource_budget':{'roots':[str(p) for p in paths],'max_bytes':budget['max_bytes']}}


def validate_deployments(host_config,nuke_config,*,controller_root,repo_root,allow_software_processes=False,application='pipeline'):
    control=Path(controller_root).resolve();repo=Path(repo_root).resolve()
    if application not in ('pipeline','nuke'):raise ValueError('PRODUCTION_APPLICATION_MISMATCH')
    deployments=[('nuke',nuke_config)] if application=='nuke' else [('houdini',host_config),('nuke',nuke_config)]
    return [_validate(raw,kind,control,repo,allow_software_processes) for kind,raw in deployments]


def _shared_env(config,control,scheduler):
    import dcc_task_runtime,houdini_bridge,nuke_bridge,vfx_pipeline
    roots=[str(Path(p.__file__).resolve().parent.parent) for p in (dcc_task_runtime,houdini_bridge,nuke_bridge,vfx_pipeline)]
    if config.get('evidence_source')=='software_test' and config.get('software_api_dir'):
        roots.insert(0,str(Path(config['software_api_dir']).resolve()))
    return {'PYTHONPATH':os.pathsep.join(dict.fromkeys(roots)),'PYTHONNOUSERSITE':'1',
        'HOUDINI_BRIDGE_STATE_DIR':str(control/'houdini-instances'),
        'HOUDINI_BRIDGE_TASK_STATE_DIR':str(control/'houdini-instances'),
        'BRIDGE_SKILLS_STATE_ROOT':str(control/'host-runtime-state'),
        'BRIDGE_ARTIFACT_LEDGER_ROOT':str(control/'artifact_ledger'),
        'BRIDGE_SKILLS_SCHEDULER_ROOT':str(scheduler)}


class _HoudiniDeploymentIdentityMismatch(ValueError):
    def __init__(self, observed):
        super().__init__('PRODUCTION_HOST_DEPLOYMENT_IDENTITY_MISMATCH')
        self.observed = observed


class _HoudiniHostStopped(ValueError):
    def __init__(self, observed, identity):
        super().__init__('PRODUCTION_HOST_STOPPED')
        self.observed = observed
        self.ready_identity = dict(identity)


def _h_config(config,work,control,*,task_id,binding_override=None):
    from houdini_bridge.client import HoudiniClient
    if not work.resolve().is_relative_to(Path(config['task_root']).resolve()):
        raise ValueError('PRODUCTION_HOST_WORKDIR_UNTRUSTED_RECONCILE_REQUIRED')
    ready_path=work/'host.ready'
    ready=json.loads(ready_path.read_text(encoding='utf-8'))
    binding=binding_override if binding_override is not None else json.loads((work/'supervisor-binding.json').read_text(encoding='utf-8'))
    supervisor_identity=binding.get('identity')
    if (not isinstance(supervisor_identity,dict) or supervisor_identity.get('task_id')!=task_id
            or not isinstance(supervisor_identity.get('launch_nonce'),str)
            or not supervisor_identity['launch_nonce']
            or Path(binding['directory']).is_symlink()
            or Path(binding['directory']).resolve()!=work.resolve()/('supervisor-'+supervisor_identity['launch_nonce'])):
        raise ValueError('PRODUCTION_SUPERVISOR_BINDING_UNTRUSTED_RECONCILE_REQUIRED')
    observed=OwnedProcessHandle(binding['directory'],supervisor_identity)
    identity=ready.get('task_host_identity')
    if not isinstance(identity,dict) or identity.get('pid')!=observed.pid or identity.get('launch_nonce')!=supervisor_identity['launch_nonce']:raise ValueError('PRODUCTION_READY_IDENTITY_INVALID')
    trusted={'task_id':task_id,'version':config['version'],'plugin_build':config['plugin_build']}
    if any(identity.get(key)!=value for key,value in trusted.items()):
        raise _HoudiniDeploymentIdentityMismatch(observed)
    if observed.poll() is not None:raise _HoudiniHostStopped(observed,identity)
    state=control/'houdini-instances/instances'
    record=json.loads((state/(str(observed.pid)+'.json')).read_text(encoding='utf-8'))
    name=record.get('token_file')
    if not isinstance(name,str) or Path(name).name!=name:raise ValueError('PRODUCTION_AUTH_TOKEN_MISSING')
    token=(state/name).read_text(encoding='utf-8')
    client = HoudiniClient(ready['port'], token=token)
    actual=client.health().get('task_host_identity')
    if not isinstance(actual,dict):raise ValueError('PRODUCTION_HEALTH_IDENTITY_MISMATCH')
    if any(actual.get(key)!=value for key,value in trusted.items()):
        raise _HoudiniDeploymentIdentityMismatch(observed)
    # A scene open/rebind is the only permitted in-place identity change while
    # the trusted host process survives a controller restart.  Every process
    # and deployment identity field must still match the ready receipt; only a
    # monotonic scene epoch may advance, and the new receipt is persisted before
    # the controller records the bound host.
    identity_without_epoch={key:value for key,value in identity.items() if key!='scene_epoch'}
    actual_without_epoch={key:value for key,value in actual.items() if key!='scene_epoch'}
    if actual_without_epoch!=identity_without_epoch:
        raise ValueError('PRODUCTION_HEALTH_IDENTITY_MISMATCH')
    if (type(identity.get('scene_epoch')) is not int
            or type(actual.get('scene_epoch')) is not int
            or actual['scene_epoch']<identity['scene_epoch']):
        raise ValueError('PRODUCTION_SCENE_EPOCH_INVALID')
    if actual['scene_epoch']!=identity['scene_epoch']:
        _reconcile_scene_transition_records(
            control, client, task_id=task_id,
            expected_identity=identity, actual_identity=actual,
            task_root=Path(config['task_root']).resolve(),
        )
        if not _scene_epoch_transition_is_authorized(
                control, task_id=task_id,
                from_epoch=identity['scene_epoch'], to_epoch=actual['scene_epoch'],
                task_root=Path(config['task_root']).resolve(),
                expected_identity=identity, actual_identity=actual):
            raise ValueError('PRODUCTION_SCENE_EPOCH_UNAUTHORIZED')
        ready={**ready,'task_host_identity':actual}
        _atomic(ready_path,ready)
        identity=actual
    return {**config,'transport':'http','host':'127.0.0.1','port':ready['port'],'token':token,
            'expected_identity':identity,'work_dir':str(work),'ledger_root':str(control/'artifact_ledger')}


def _scene_transition_path(control):
    return Path(control).resolve() / 'scene-transitions.json'


def _scene_transition_records(control):
    path = _scene_transition_path(control)
    if not path.is_file():
        return []
    try:
        payload = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError) as exc:
        raise ValueError('PRODUCTION_SCENE_TRANSITION_STORE_INVALID') from exc
    if not isinstance(payload, dict) or payload.get('schema') != 'bridge.production.scene-transitions/1.0':
        raise ValueError('PRODUCTION_SCENE_TRANSITION_STORE_INVALID')
    records = payload.get('records')
    if not isinstance(records, list) or any(not isinstance(item, dict) for item in records):
        raise ValueError('PRODUCTION_SCENE_TRANSITION_STORE_INVALID')
    return records


def _scene_transition_operation_store_path(control, task_id):
    key = hashlib.sha256(str(task_id).encode('utf-8')).hexdigest()[:16]
    # Task hosts receive HOUDINI_BRIDGE_STATE_DIR=<control>/houdini-instances;
    # the add-on's _state_dir() therefore persists its normal fx_operations
    # store below that installation state root, not beside production-hosts.
    return (Path(control).resolve() / 'houdini-instances' / 'fx_operations'
            / ('ops_' + key + '.json'))


def _scene_transition_operation_digest(record):
    body = {key: value for key, value in record.items()
            if key != 'operation_receipt_sha256'}
    return hashlib.sha256(json.dumps(
        body, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
        .encode('utf-8')).hexdigest()


def _scene_transition_formal_record(control, record):
    operation_id = str(record.get('operation_id') or '')
    task_id = str(record.get('task_id') or '')
    if not operation_id or not task_id:
        return None
    path = _scene_transition_operation_store_path(control, task_id)
    try:
        from houdini_bridge.render_observation_budget import read_store_payload, validate_store
        from houdini_bridge.operation_store import resolve_record
        store = json.loads(read_store_payload(path))
        validate_store(store)
        formal = resolve_record(path, store, operation_id, family='scene_transitions')
    except (OSError, ValueError, RecursionError):
        return None
    if not isinstance(formal, dict) or formal.get('task_id') != task_id:
        return None
    return formal


def _reconcile_scene_transition_records(control, client, *, task_id, expected_identity,
                                        actual_identity, task_root):
    """Reconcile a host-owned INTENT before accepting its live epoch edge.

    The controller-side scene-transitions file is only an attachment. The
    host's scene transition entry in the normal per-task operation store is
    the authority and is updated by the host under its durable operation lock.
    """
    path = _scene_transition_path(control)
    records = _scene_transition_records(control)
    changed = False
    for index, record in enumerate(records):
        if (record.get('status') != 'INTENT' or record.get('task_id') != task_id
                or not record.get('operation_id')
                or record.get('before_scene_epoch') != expected_identity.get('scene_epoch')):
            continue
        try:
            response = client.call('scene.reconcile_transition', {
                'task_id': task_id,
                'operation_id': str(record['operation_id']),
            })
        except Exception:
            continue
        formal = response.get('scene_transition') if isinstance(response, dict) else None
        if (not isinstance(formal, dict) or formal.get('state') != 'COMPLETED'
                or formal.get('task_id') != task_id
                or formal.get('operation_id') != record.get('operation_id')
                or formal.get('request_id') != record.get('request_id')
                or formal.get('request_sha256') != record.get('request_sha256')
                or formal.get('before_scene_epoch') != record.get('before_scene_epoch')
                or formal.get('after_scene_epoch') != actual_identity.get('scene_epoch')
                or formal.get('before_identity') != record.get('before_identity')
                or formal.get('after_identity') != actual_identity
                or formal.get('operation_receipt_sha256') != _scene_transition_operation_digest(formal)):
            continue
        snapshot = _scene_transition_snapshot_from_formal(
            control, record, formal, task_root=task_root)
        if snapshot is None:
            continue
        updated = dict(record)
        updated.update({
            'status': 'COMPLETED',
            'recovered_from_intent': True,
            'completed_at': 'controller-reconnect',
            'after_scene_epoch': formal.get('after_scene_epoch'),
            'after_identity': formal.get('after_identity'),
            'result': snapshot,
            'operation_store_cas': formal.get('store_cas'),
            'operation_receipt_sha256': formal.get('operation_receipt_sha256'),
            'formal_operation': formal,
        })
        records[index] = updated
        changed = True
    if changed:
        _atomic(path, {
            'schema': 'bridge.production.scene-transitions/1.0',
            'task_id': task_id, 'records': records,
        })
    return changed


def _scene_transition_snapshot(control, record, *, task_root, require_source=False):
    task_root = Path(task_root).expanduser().resolve()
    request = record.get('request') if isinstance(record.get('request'), dict) else {}
    raw_path = str(request.get('path') or '')
    digest = str(request.get('sha256') or '').lower()
    if not raw_path or len(digest) != 64 or any(char not in '0123456789abcdef' for char in digest):
        return None
    raw_source = Path(raw_path).expanduser()
    if raw_source.is_symlink():
        return None
    source = raw_source.resolve()
    if not source.is_relative_to(task_root):
        return None
    if require_source and not source.is_file():
        return None
    snapshot_root = Path(control).resolve() / 'scene-transition-snapshots' / str(task_id_for_snapshot(record))
    snapshot_root.mkdir(parents=True, exist_ok=True)
    snapshot = snapshot_root / (digest + '.hip')
    if snapshot.is_symlink():
        return None
    if not snapshot.is_file():
        if not require_source:
            return None
        if hashlib.sha256(source.read_bytes()).hexdigest() != digest:
            return None
        temporary = snapshot.with_name('.' + snapshot.name + '.tmp')
        temporary.write_bytes(source.read_bytes())
        os.chmod(temporary, 0o400)
        atomic_replace(temporary,snapshot,owned_root=Path(control).resolve())
    try:
        if hashlib.sha256(snapshot.read_bytes()).hexdigest() != digest:
            return None
        if require_source and hashlib.sha256(source.read_bytes()).hexdigest() != digest:
            return None
    except OSError:
        return None
    return {'path': str(source), 'sha256': digest, 'snapshot_path': str(snapshot),
            'snapshot_sha256': digest}


def _scene_transition_snapshot_from_formal(control, record, formal, *, task_root):
    """Copy a verified host-owned transition snapshot into controller state."""
    task_root = Path(task_root).expanduser().resolve()
    request = record.get('request') if isinstance(record.get('request'), dict) else {}
    raw_path = str(request.get('path') or '')
    raw_source = Path(raw_path).expanduser()
    digest = str(request.get('sha256') or '').lower()
    if (not raw_path or raw_source.is_symlink() or len(digest) != 64
            or any(char not in '0123456789abcdef' for char in digest)):
        return None
    source = raw_source.resolve()
    if not source.is_relative_to(task_root):
        return None
    formal_result = formal.get('result')
    if (not isinstance(formal_result, dict)
            or formal_result.get('path') != str(source)
            or str(formal_result.get('sha256') or '').lower() != digest
            or str(formal_result.get('snapshot_sha256') or '').lower() != digest):
        return None
    raw_host_snapshot = Path(str(formal_result.get('snapshot_path') or '')).expanduser()
    if raw_host_snapshot.is_symlink() or not raw_host_snapshot.is_file():
        return None
    host_snapshot = raw_host_snapshot.resolve()
    host_snapshot_root = (Path(control).resolve() / 'houdini-instances'
                          / 'scene-transition-snapshots'
                          / str(task_id_for_snapshot(record))).resolve()
    if not host_snapshot.is_relative_to(host_snapshot_root):
        return None
    try:
        payload = host_snapshot.read_bytes()
    except OSError:
        return None
    if hashlib.sha256(payload).hexdigest() != digest:
        return None
    controller_root = (Path(control).resolve() / 'scene-transition-snapshots'
                       / str(task_id_for_snapshot(record)))
    controller_root.mkdir(parents=True, exist_ok=True)
    snapshot = controller_root / (digest + '.hip')
    if snapshot.is_symlink():
        return None
    if snapshot.is_file():
        try:
            if hashlib.sha256(snapshot.read_bytes()).hexdigest() != digest:
                return None
        except OSError:
            return None
    else:
        temporary = snapshot.with_name('.' + snapshot.name + '.tmp')
        try:
            temporary.write_bytes(payload)
            os.chmod(temporary, 0o400)
            atomic_replace(temporary,snapshot,owned_root=controller_root)
        except OSError:
            try:
                remove_owned_path(temporary,owned_root=controller_root)
            except OSError:
                pass
            return None
    return {'path': str(source), 'sha256': digest, 'snapshot_path': str(snapshot),
            'snapshot_sha256': digest}


def task_id_for_snapshot(record):
    return ''.join(char if char.isalnum() or char in '._-' else '_' for char in str(record.get('task_id') or ''))[:120] or 'unbound'


def _scene_transition_record_is_valid(record, *, control, task_id, task_root, expected_identity, actual_identity):
    if (record.get('schema') != 'bridge.production.scene-transition/1.0'
            or record.get('status') != 'COMPLETED'
            or record.get('kind') != 'houdini'
            or record.get('task_id') != task_id
            or record.get('command') not in {'scene.open_hip', 'scene.reopen_task_hip', 'scene.reopen_owned_hip'}):
        return False
    before = record.get('before_identity')
    after = record.get('after_identity')
    if not isinstance(before, dict) or not isinstance(after, dict):
        return False
    if before.get('task_id') != task_id or after.get('task_id') != task_id:
        return False
    if before.get('scene_epoch') != record.get('before_scene_epoch') or after.get('scene_epoch') != record.get('after_scene_epoch'):
        return False
    if type(record.get('before_scene_epoch')) is not int or type(record.get('after_scene_epoch')) is not int:
        return False
    if record['after_scene_epoch'] <= record['before_scene_epoch']:
        return False
    identity_keys = ('task_id', 'session_id', 'launch_nonce', 'pid', 'process_generation', 'plugin_build', 'version')
    if any(before.get(key) != after.get(key) for key in identity_keys):
        return False
    if any(before.get(key) != expected_identity.get(key) for key in identity_keys):
        return False
    if any(after.get(key) != actual_identity.get(key) for key in identity_keys):
        return False
    result = record.get('result')
    if not isinstance(result, dict):
        return False
    snapshot = _scene_transition_snapshot(control, record, task_root=task_root, require_source=False)
    valid = (isinstance(snapshot, dict)
            and result.get('path') == snapshot['path']
            and str(result.get('sha256') or '').lower() == snapshot['sha256']
            and result.get('snapshot_path') == snapshot['snapshot_path']
            and result.get('snapshot_sha256') == snapshot['snapshot_sha256'])
    operation_id = str(record.get('operation_id') or '')
    if not valid or not operation_id:
        return valid
    formal = _scene_transition_formal_record(control, record)
    if (not isinstance(formal, dict) or formal.get('state') != 'COMPLETED'
            or formal.get('operation_id') != operation_id
            or formal.get('request_id') != record.get('request_id')
            or formal.get('request_sha256') != record.get('request_sha256')
            or formal.get('before_scene_epoch') != record.get('before_scene_epoch')
            or formal.get('after_scene_epoch') != record.get('after_scene_epoch')
            or record.get('operation_store_cas') != formal.get('store_cas')
            or record.get('operation_receipt_sha256') != formal.get('operation_receipt_sha256')
            or formal.get('operation_receipt_sha256') != _scene_transition_operation_digest(formal)):
        return False
    formal_result = formal.get('result')
    # The controller and host each keep an immutable copy under their own
    # private state root.  Their snapshot paths therefore differ, while the
    # loaded HIP content identity must be identical.
    if (not isinstance(formal_result, dict)
            or formal_result.get('path') != result.get('path')
            or formal_result.get('sha256') != result.get('sha256')
            or formal_result.get('snapshot_sha256') != result.get('snapshot_sha256')):
        return False
    return (formal.get('before_identity') == record.get('before_identity')
            and formal.get('after_identity') == record.get('after_identity'))


def _scene_epoch_transition_is_authorized(control, *, task_id, from_epoch, to_epoch,
                                          task_root, expected_identity, actual_identity):
    """Authorize a live epoch advance only through a completed controller load.

    A Houdini process can advance its scene epoch for an external load/clear
    without touching controller state.  Such a change is not a reconnect
    signal.  The only accepted edge is a durable completed scene operation
    whose exact task, process identity, HIP path and content hash match.
    """
    records = _scene_transition_records(control)
    current = int(from_epoch)
    visited = set()
    while current < int(to_epoch):
        candidates = []
        for index, record in enumerate(records):
            if index in visited or record.get('before_scene_epoch') != current:
                continue
            if not _scene_transition_record_is_valid(
                    record, control=control, task_id=task_id, task_root=task_root,
                    expected_identity=expected_identity, actual_identity=actual_identity):
                if (record.get('status') == 'INTENT'
                        and record.get('task_id') == task_id
                        and record.get('before_scene_epoch') == current
                        and int(to_epoch) == current + 1):
                    recovered = _recover_interrupted_scene_transition(
                        control, record, task_root=task_root,
                        actual_identity=actual_identity,
                    )
                    if recovered:
                        records = _scene_transition_records(control)
                        candidates.append((current + 1, index))
                continue
            after = record.get('after_scene_epoch')
            if type(after) is int and current < after <= int(to_epoch):
                candidates.append((after, index))
        if len(candidates) != 1:
            return False
        current, index = sorted(candidates)[0]
        visited.add(index)
    return current == int(to_epoch)


def _recover_interrupted_scene_transition(control, record, *, task_root, actual_identity):
    """Close an intent left by a controller crash only from the same HIP fact.

    The source must still have the exact requested digest.  The durable snapshot
    is then the fact used by future controller restarts, so later saves to the
    mutable source path cannot invalidate a completed load receipt.
    """
    # Production records are completed by the host against the same durable
    # operation store. A controller-only rewrite would create a second
    # authorization source, so only legacy/unit records without an operation
    # identity use this local fallback.
    if record.get('operation_id'):
        return False
    snapshot = _scene_transition_snapshot(control, record, task_root=task_root, require_source=True)
    if snapshot is None:
        return False
    before = record.get('before_scene_epoch')
    if type(before) is not int:
        return False
    recovered = dict(record)
    recovered.update({
        'status': 'COMPLETED',
        'recovered_from_intent': True,
        'completed_at': 'controller-reconnect',
        'after_scene_epoch': before + 1,
        'after_identity': dict(actual_identity),
        'result': snapshot,
    })
    records = _scene_transition_records(control)
    try:
        index = next(index for index, item in enumerate(records) if item is record)
    except StopIteration:
        # Records are reloaded from JSON, so identity is not shared; match the
        # unique intent by task, command, epoch and requested content instead.
        index = next((index for index, item in enumerate(records)
                      if item.get('status') == 'INTENT'
                      and item.get('task_id') == record.get('task_id')
                      and item.get('before_scene_epoch') == before
                      and item.get('request') == record.get('request')), -1)
    if index < 0:
        return False
    records[index] = recovered
    _atomic(_scene_transition_path(control), {
        'schema': 'bridge.production.scene-transitions/1.0',
        'task_id': str(record.get('task_id') or ''), 'records': records,
    })
    return True


def _stopped_prior(prior,kind,config,task_id):
    """A signed wait receipt for this exact old host is required to restart."""
    identity=prior.get('expected_identity')
    if (not isinstance(identity,dict) or identity.get('task_id')!=task_id
            or identity.get('plugin_build')!=config['plugin_build']
            or not isinstance(identity.get('pid'),int)
            or not isinstance(identity.get('launch_nonce'),str)):
        raise ValueError('PRODUCTION_OLD_HOST_IDENTITY_INVALID')
    work=Path(prior['work_dir']).resolve()
    if not work.is_relative_to(Path(config['task_root']).resolve()):
        raise ValueError('PRODUCTION_OLD_HOST_OUTSIDE_TASK')
    if kind=='nuke':
        expected=prior.get('supervisor_identity')
        supervisor=Path(prior.get('supervisor_dir','')).resolve()
        if (not isinstance(expected,dict) or expected.get('launch_nonce')!=identity['launch_nonce']
                or expected.get('process_generation')!=identity.get('process_generation')
                or supervisor!=work/'supervisor'):
            raise ValueError('PRODUCTION_OLD_HOST_IDENTITY_INVALID')
    else:
        expected={'task_id':task_id,'launch_nonce':identity['launch_nonce']}
        supervisor=work/('supervisor-'+identity['launch_nonce'])
    observed=OwnedProcessHandle(supervisor,expected)
    if observed.pid!=identity['pid'] or observed.poll() is None or observed.receipt() is None:
        raise ValueError('PRODUCTION_OLD_HOST_STOP_UNKNOWN')
    return work


def _launch_h(config,work,task_id,control,scheduler,repo):
    from houdini_bridge import task_host as houdini_host
    ensure_private_directory(work)
    args=argparse.Namespace(task_id=task_id,work_dir=str(work),addon_root=str(repo/'plugins/houdini'),
        houdini_bin=config['executable'],version=config['version'],max_seconds=config['session_seconds'],ready_timeout=10,poll_seconds=.01,warmup=False,
        supervisor_executable=config['supervisor_executable'],resource_budget=config['resource_budget'],environment=_shared_env(config,control,scheduler),
        evidence_source=config['evidence_source'],allow_software_processes=config['evidence_source']=='software_test')
    if 'software_launch_script' in config:
        args.software_launch_script=config['software_launch_script']
        args.software_launch_script_sha256=config['software_launch_script_sha256']
    with contextlib.redirect_stdout(io.StringIO()) as output:code=houdini_host.start(args)
    if code:raise RuntimeError('PRODUCTION_HOUDINI_START_FAILED:'+output.getvalue())


def _reclaim_mismatched_houdini(work, task_id, observed, *, persist_stopped, expected_stopped_identity=None):
    """Reclaim only this signed supervisor child, retaining its stop evidence."""
    from houdini_bridge import task_host as houdini_host
    if (observed.identity.get('task_id') != task_id
            or observed.directory.resolve() != work.resolve()/('supervisor-'+observed.identity['launch_nonce'])):
        raise ValueError('PRODUCTION_HOST_IDENTITY_RECONCILE_REQUIRED')
    try:
        with houdini_host._owner_lock(work):
            ready_path=work/'host.ready'
            ready=json.loads(ready_path.read_text(encoding='utf-8'))
            identity=ready.get('task_host_identity',{})
            if (identity.get('pid')!=observed.pid
                    or identity.get('launch_nonce')!=observed.identity['launch_nonce']):
                raise ValueError('PRODUCTION_HOST_IDENTITY_RECONCILE_REQUIRED')
            if expected_stopped_identity is not None:
                binding=json.loads((work/'supervisor-binding.json').read_text(encoding='utf-8'))
                if (identity!=expected_stopped_identity
                        or binding.get('identity')!=observed.identity
                        or Path(binding['directory']).is_symlink()
                        or Path(binding['directory']).resolve()!=observed.directory.resolve()):
                    raise ValueError('PRODUCTION_HOST_IDENTITY_RECONCILE_REQUIRED')
                observed=OwnedProcessHandle(binding['directory'],binding['identity'])
                if (observed.pid!=identity['pid'] or observed.poll() is None
                        or observed.receipt() is None):
                    raise ValueError('PRODUCTION_HOST_IDENTITY_RECONCILE_REQUIRED')
            # The in-process launcher owns the original handle and its parent
            # wait; a restarted controller uses the same signed supervisor facts.
            child=houdini_host._ACTIVE_CHILDREN.get(observed.pid)
            if (child is None or child.identity!=observed.identity
                    or child.directory.resolve()!=observed.directory.resolve()):
                child=observed
            if child.poll() is None:
                if expected_stopped_identity is not None:
                    raise ValueError('PRODUCTION_HOST_IDENTITY_RECONCILE_REQUIRED')
                houdini_host._reclaim_child(work/'host.stop',child)
            if child.poll() is None or child.receipt() is None:
                raise ValueError('PRODUCTION_HOST_IDENTITY_RECONCILE_REQUIRED')
            current=json.loads(ready_path.read_text(encoding='utf-8'))
            current_identity=current.get('task_host_identity',{})
            if (current_identity.get('pid')!=observed.pid
                    or current_identity.get('launch_nonce')!=observed.identity['launch_nonce']):
                raise ValueError('PRODUCTION_HOST_IDENTITY_RECONCILE_REQUIRED')
            # Keep readiness recoverable until the deployment record no longer
            # names this rejected host; the original signed stop remains intact.
            persist_stopped()
            remove_owned_path(ready_path,owned_root=work)
            if houdini_host._ACTIVE_CHILDREN.get(observed.pid) is child:
                houdini_host._ACTIVE_CHILDREN.pop(observed.pid,None)
    except (OSError,KeyError,TypeError,json.JSONDecodeError) as exc:
        raise ValueError('PRODUCTION_HOST_IDENTITY_RECONCILE_REQUIRED') from exc


def _nuke_restart_candidate(config,task_id,old_work,generation):
    candidates=[]
    for path in Path(config['task_root']).glob('nuke-host-*'):
        if path.is_symlink() or not path.resolve().is_relative_to(Path(config['task_root']).resolve()):
            raise ValueError('PRODUCTION_RESTART_WORKDIR_INVALID')
        intent=path/'launch.json'
        if path.resolve()==old_work or not intent.is_file():continue
        raw=json.loads(intent.read_text(encoding='utf-8'))
        identity=raw.get('identity',{})
        if (identity.get('task_id')==task_id and identity.get('process_generation')==generation
                and identity.get('plugin_build')==config['plugin_build']):
            candidates.append(path)
    if len(candidates)>1:raise ValueError('PRODUCTION_MULTIPLE_HOSTS_RECONCILE_REQUIRED')
    return candidates[0] if candidates else None


def ensure_hosts(host_config,nuke_config,*,task_id,controller_root,repo_root,scheduler_root,allow_software_processes=False,application='pipeline'):
    control=Path(controller_root).resolve()
    with _deployment_lock(control):
        return _ensure_hosts_locked(host_config,nuke_config,task_id=task_id,controller_root=control,
            repo_root=repo_root,scheduler_root=scheduler_root,allow_software_processes=allow_software_processes,application=application)


def _ensure_hosts_locked(host_config,nuke_config,*,task_id,controller_root,repo_root,scheduler_root,allow_software_processes,application='pipeline'):
    from nuke_bridge import task_host as nuke_host
    from houdini_bridge import task_host as houdini_host
    control=Path(controller_root).resolve();repo=Path(repo_root).resolve();scheduler=Path(scheduler_root).resolve()
    configs=validate_deployments(host_config,nuke_config,controller_root=control,repo_root=repo,
                                allow_software_processes=allow_software_processes,application=application)
    state_file=control/'production-hosts.json'
    fingerprint=hashlib.sha256(json.dumps(configs,sort_keys=True).encode()).hexdigest()
    saved=json.loads(state_file.read_text(encoding='utf-8')) if state_file.is_file() else {'task_id':task_id,'config_sha256':fingerprint,'hosts':{}}
    if saved.get('task_id')!=task_id or saved.get('config_sha256')!=fingerprint:raise ValueError('PRODUCTION_DEPLOYMENT_CHANGED')
    restarts=saved.setdefault('restarts',{})
    result={}
    for config in configs:
        kind=config['application'];prior=saved['hosts'].get(kind);work=control/(kind+'-task-host')
        if kind=='houdini':
            try:
                if prior:
                    work=Path(prior['work_dir']).resolve()
                    if restarts.get(kind):
                        old=_stopped_prior(prior,kind,config,task_id)
                        if restarts[kind].get('old_nonce')!=prior['expected_identity']['launch_nonce']:
                            raise ValueError('PRODUCTION_RESTART_INTENT_MISMATCH')
                        # A crash after launching must reconnect the new child,
                        # never launch a second child into the same work directory.
                        known=restarts[kind].get('known_supervisors')
                        if not isinstance(known,list) or any(not isinstance(name,str) for name in known):
                            raise ValueError('PRODUCTION_RESTART_INTENT_MISMATCH')
                        candidates=[p for p in work.glob('supervisor-*') if p.is_dir() and p.name not in known]
                        if candidates:
                            if len(candidates)!=1:raise ValueError('PRODUCTION_MULTIPLE_HOSTS_RECONCILE_REQUIRED')
                            binding=json.loads((work/'supervisor-binding.json').read_text(encoding='utf-8'))
                            candidate=candidates[0].resolve()
                            if Path(binding['directory']).resolve()!=candidate:
                                nonce=candidate.name.removeprefix('supervisor-')
                                recovered={'directory':str(candidate),'identity':{'task_id':task_id,'launch_nonce':nonce}}
                                try:
                                    bound=_h_config(config,work,control,task_id=task_id,binding_override=recovered)
                                except _HoudiniDeploymentIdentityMismatch:
                                    raise
                                except (OSError,ValueError,KeyError):
                                    raise ValueError('PRODUCTION_RESTART_PENDING') from None
                                identity=bound['expected_identity']
                                if identity.get('task_id')!=task_id or identity.get('plugin_build')!=config['plugin_build']:
                                    raise ValueError('PRODUCTION_RESTART_IDENTITY_INVALID')
                                _atomic(work/'supervisor-binding.json',recovered)
                                binding=recovered
                            observed=OwnedProcessHandle(binding['directory'],binding['identity'])
                            if observed.poll() is not None:raise ValueError('PRODUCTION_RESTART_STOPPED_RECONCILE_REQUIRED')
                            bound=_h_config(config,work,control,task_id=task_id)
                        else:
                            _launch_h(config,work,task_id,control,scheduler,repo)
                            bound=_h_config(config,work,control,task_id=task_id)
                    else:
                        binding=json.loads((work/'supervisor-binding.json').read_text(encoding='utf-8'))
                        if binding['identity'].get('launch_nonce')!=prior['expected_identity']['launch_nonce']:
                            raise ValueError('PRODUCTION_UNRECORDED_HOST')
                        try:bound=_h_config(config,work,control,task_id=task_id)
                        except ValueError as exc:
                            if str(exc)!='PRODUCTION_HOST_STOPPED':raise
                            _stopped_prior(prior,kind,config,task_id)
                            restarts[kind]={'old_nonce':prior['expected_identity']['launch_nonce'],
                                            'known_supervisors':sorted(p.name for p in work.glob('supervisor-*') if p.is_dir())}
                            _atomic(state_file,saved)
                            _launch_h(config,work,task_id,control,scheduler,repo)
                            bound=_h_config(config,work,control,task_id=task_id)
                else:
                    if not (work/'host.ready').is_file():
                        _launch_h(config,work,task_id,control,scheduler,repo)
                    try:
                        bound=_h_config(config,work,control,task_id=task_id)
                    except _HoudiniHostStopped as stopped:
                        _reclaim_mismatched_houdini(work,task_id,stopped.observed,
                            persist_stopped=lambda:_atomic(state_file,saved),
                            expected_stopped_identity=stopped.ready_identity)
                        _launch_h(config,work,task_id,control,scheduler,repo)
                        bound=_h_config(config,work,control,task_id=task_id)
            except _HoudiniDeploymentIdentityMismatch as exc:
                def persist_rejected_stop():
                    prior_identity=(prior or {}).get('expected_identity',{})
                    if (prior_identity.get('pid')==exc.observed.pid
                            and prior_identity.get('launch_nonce')==exc.observed.identity['launch_nonce']):
                        saved['hosts'].pop(kind,None)
                        restarts.pop(kind,None)
                    elif restarts.get(kind):
                        restarts[kind]['known_supervisors']=sorted(p.name for p in work.glob('supervisor-*') if p.is_dir())
                    _atomic(state_file,saved)
                _reclaim_mismatched_houdini(work,task_id,exc.observed,persist_stopped=persist_rejected_stop)
                raise ValueError('PRODUCTION_HOST_DEPLOYMENT_IDENTITY_MISMATCH_STOP_CONFIRMED') from exc
        else:
            if prior:
                if restarts.get(kind):
                    old=_stopped_prior(prior,kind,config,task_id)
                    generation=restarts[kind].get('generation')
                    if (restarts[kind].get('old_nonce')!=prior['expected_identity']['launch_nonce']
                            or type(generation) is not int or generation!=prior['expected_identity']['process_generation']+1):
                        raise ValueError('PRODUCTION_RESTART_INTENT_MISMATCH')
                    candidate=_nuke_restart_candidate(config,task_id,old,generation)
                    if candidate:
                        receipt=nuke_host.reconnect(candidate)
                    else:
                        receipt=nuke_host.start(task_id=task_id,task_root=config['task_root'],nuke_executable=config['executable'],
                            addon_path=repo/'plugins/nuke/nuke_bridge_addon.py',supervisor_executable=config['supervisor_executable'],
                            version=config['version'],process_generation=generation,budget_seconds=config['session_seconds'],
                            snapshot=config.get('snapshot'),resource_budget=config['resource_budget'],ledger_root=control/'artifact_ledger',
                            scheduler_root=scheduler,software_api=config['evidence_source']=='software_test',software_api_dir=config.get('software_api_dir'))
                else:
                    try:receipt=nuke_host.reconnect(prior['work_dir'])
                    except RuntimeError as exc:
                        if str(exc)!='owned host is stopped':raise
                        _stopped_prior(prior,kind,config,task_id)
                        generation=prior['expected_identity']['process_generation']+1
                        restarts[kind]={'old_nonce':prior['expected_identity']['launch_nonce'],'generation':generation}
                        _atomic(state_file,saved)
                        receipt=nuke_host.start(task_id=task_id,task_root=config['task_root'],nuke_executable=config['executable'],
                            addon_path=repo/'plugins/nuke/nuke_bridge_addon.py',supervisor_executable=config['supervisor_executable'],
                            version=config['version'],process_generation=generation,budget_seconds=config['session_seconds'],
                            snapshot=config.get('snapshot'),resource_budget=config['resource_budget'],ledger_root=control/'artifact_ledger',
                            scheduler_root=scheduler,software_api=config['evidence_source']=='software_test',software_api_dir=config.get('software_api_dir'))
            else:
                # Reclaim a controller crash after native readiness, before
                # the combined deployment record was committed.
                candidates=[]
                for path in Path(config['task_root']).glob('nuke-host-*'):
                    intent=path/'launch.json'
                    if intent.is_file() and json.loads(intent.read_text(encoding='utf-8')).get('identity',{}).get('task_id')==task_id:
                        candidates.append(path)
                if len(candidates)>1:raise ValueError('PRODUCTION_MULTIPLE_HOSTS_RECONCILE_REQUIRED')
                if candidates:receipt=nuke_host.reconnect(candidates[0])
                else:
                    receipt=nuke_host.start(task_id=task_id,task_root=config['task_root'],nuke_executable=config['executable'],
                        addon_path=repo/'plugins/nuke/nuke_bridge_addon.py',supervisor_executable=config['supervisor_executable'],
                        version=config['version'],budget_seconds=config['session_seconds'],snapshot=config.get('snapshot'),
                        resource_budget=config['resource_budget'],ledger_root=control/'artifact_ledger',scheduler_root=scheduler,
                        software_api=config['evidence_source']=='software_test',software_api_dir=config.get('software_api_dir'))
            bound={**config,**receipt,'evidence_source':config['evidence_source'],'transport':'tcp','host':'127.0.0.1','ledger_root':str(control/'artifact_ledger')}
        saved['hosts'][kind]=bound;restarts.pop(kind,None);_atomic(state_file,saved);result[kind]=bound
    return result.get('houdini'),result['nuke']


def stop_hosts(controller_root):
    from nuke_bridge import task_host as nuke_host
    from houdini_bridge import task_host as houdini_host
    control=Path(controller_root).resolve()
    with _deployment_lock(control):
        path=control/'production-hosts.json';saved=json.loads(path.read_text(encoding='utf-8'));results={}
        if saved.get('restarts'):
            raise ValueError('PRODUCTION_RESTART_PENDING_RECONCILE_REQUIRED')
        for kind,config in saved['hosts'].items():
            if kind=='nuke':results[kind]=nuke_host.stop(config['work_dir'])
            else:
                with contextlib.redirect_stdout(io.StringIO()) as output:
                    code=houdini_host.stop(argparse.Namespace(work_dir=config['work_dir'],timeout=3,exit_grace=3))
                results[kind]={'returncode':code,'receipt':json.loads(output.getvalue())}
        return results

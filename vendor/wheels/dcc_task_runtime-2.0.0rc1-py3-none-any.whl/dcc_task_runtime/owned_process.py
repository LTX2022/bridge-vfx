"""Durable observations from a supervisor that owns and waits for one child.

This module is also the fixed supervisor executable. A restarted controller
reads its exact receipt; PID disappearance or a worker's own result is never
used as a substitute for wait() returning on the owned process.
"""
from __future__ import annotations
import hashlib
import hmac
import json
import os
from pathlib import Path
import secrets
import signal
import stat
import subprocess
import sys
import time
import threading

if __package__:
    from .platform_support import atomic_write, ensure_private_directory, open_private_file, process_identity
    from .windows_process import WindowsJobProcess
else:
    import importlib
    import types
    _support_root = Path(__file__).resolve().parent
    _support_name = '_bridge_owned_support_' + hashlib.sha256(str(_support_root).encode()).hexdigest()
    _support_package = types.ModuleType(_support_name)
    _support_package.__package__ = _support_name
    _support_package.__path__ = [str(_support_root)]
    sys.modules.setdefault(_support_name, _support_package)
    _support = importlib.import_module(_support_name + '.platform_support')
    atomic_write = _support.atomic_write
    ensure_private_directory = _support.ensure_private_directory
    open_private_file = _support.open_private_file
    process_identity = _support.process_identity
    WindowsJobProcess = importlib.import_module(_support_name + '.windows_process').WindowsJobProcess

SCHEMA = 'bridge.owned_process/1'
MAX_LOG_BYTES = 1024 * 1024


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def execution_returncode(receipt):
    """Separate execution success from a signed observation that the tree stopped.

    Legacy receipts preserve stop facts and a nonzero leader status, but their
    leader zero alone cannot establish success of any unobserved descendants.
    """
    code = receipt.get('exit_code')
    if type(code) is not int:
        raise ValueError('SUPERVISOR_EXECUTION_NOT_BOUND')
    if 'execution_protocol' not in receipt:
        return code if code != 0 else 2
    unobserved = receipt.get('descendant_result_unobserved')
    reason = receipt.get('stop_reason')
    supervisor_code = 2 if unobserved or (reason is not None and code == 0) else 0
    result = ('failed' if reason is not None or code != 0 else
              'unknown' if unobserved else 'succeeded')
    if (type(receipt.get('execution_protocol')) is not int or receipt['execution_protocol'] != 1
            or type(unobserved) is not bool
            or (reason is not None and not isinstance(reason, str))
            or type(receipt.get('supervisor_exit_code')) is not int
            or receipt['supervisor_exit_code'] != supervisor_code
            or receipt.get('execution_result') != result):
        raise ValueError('SUPERVISOR_EXECUTION_NOT_BOUND')
    return supervisor_code if supervisor_code else code


def _atomic(path, value):
    path = Path(path)
    atomic_write(path, _canonical(value), owned_root=path.parent)


def _read(path):
    path = Path(path)
    if path.is_symlink(): raise ValueError('SUPERVISOR_SYMLINK')
    return json.loads(path.read_text(encoding='utf-8'))


def _signed_write(directory, payload):
    key = (directory / 'receipt.key').read_bytes()
    _atomic(directory / (payload['event'] + '.json'), {
        'payload': payload, 'signature': hmac.new(key, _canonical(payload), hashlib.sha256).hexdigest()})


def read_receipt(directory, event, *, identity):
    directory = Path(directory)
    path = directory / (event + '.json')
    if not path.exists(): return None
    envelope = _read(path); payload = envelope['payload']
    key_path = directory / 'receipt.key'
    if key_path.is_symlink(): raise ValueError('SUPERVISOR_SYMLINK')
    expected = hmac.new(key_path.read_bytes(), _canonical(payload), hashlib.sha256).hexdigest()
    if (not hmac.compare_digest(expected, str(envelope.get('signature', '')))
            or payload.get('schema') != SCHEMA or payload.get('event') != event
            or payload.get('identity') != identity):
        raise ValueError('SUPERVISOR_RECEIPT_MISMATCH')
    if event == 'started' and (os.name == 'nt' or payload.get('platform') == 'windows'):
        birth = payload.get('process_birth')
        job = payload.get('job')
        if (payload.get('platform') != 'windows' or type(payload.get('pid')) is not int
                or payload['pid'] <= 0 or not isinstance(birth, str) or not birth.isdigit()
                or int(birth) <= 0 or not isinstance(job, dict)
                or not isinstance(job.get('name'), str) or not job['name'].startswith('BridgeOwnedJob-')
                or job.get('assigned_at_creation') is not True or job.get('kill_on_close') is not True
                or job.get('process_is_in_job') is not True):
            raise ValueError('SUPERVISOR_WINDOWS_START_NOT_BOUND')
    if event == 'stopped':
        start = read_receipt(directory, 'started', identity=identity)
        if (not start or payload.get('started_sha256') != hashlib.sha256(_canonical(start)).hexdigest()
                or payload.get('pid') != start.get('pid') or payload.get('observed_by') != 'owned_child_wait'
                or type(payload.get('exit_code')) is not int):
            raise ValueError('SUPERVISOR_STOP_NOT_BOUND')
        if 'execution_protocol' in start or 'execution_protocol' in payload:
            if (type(start.get('execution_protocol')) is not int or start['execution_protocol'] != 1
                    or type(payload.get('execution_protocol')) is not int
                    or payload['execution_protocol'] != start['execution_protocol']):
                raise ValueError('SUPERVISOR_EXECUTION_NOT_BOUND')
            execution_returncode(payload)
        if start.get('platform') == 'windows':
            if (payload.get('platform') != 'windows'
                    or payload.get('process_birth') != start['process_birth']
                    or payload.get('job') != start['job'] or payload.get('child_wait_observed') is not True
                    or type(payload.get('job_active_processes')) is not int
                    or payload['job_active_processes'] != 0):
                raise ValueError('SUPERVISOR_WINDOWS_STOP_NOT_BOUND')
    return payload


class OwnedProcessHandle:
    def __init__(self, directory, identity, *, supervisor=None):
        self.directory = Path(directory); self.identity = dict(identity)
        self._supervisor = supervisor
        self.started = read_receipt(self.directory, 'started', identity=self.identity)
        if self.started is None: raise ValueError('SUPERVISOR_START_UNCONFIRMED')
        self.pid = self.started['pid']; self.returncode = None

    def poll(self):
        receipt = read_receipt(self.directory, 'stopped', identity=self.identity)
        if receipt is not None: self.returncode = execution_returncode(receipt)
        return self.returncode

    def terminate(self):
        _atomic(self.directory / 'cancel.json', {'identity': self.identity})

    def kill(self):
        self.terminate()

    def wait(self, timeout=None):
        deadline = time.monotonic() + timeout if timeout is not None else None
        while self.poll() is None:
            if deadline is not None and time.monotonic() >= deadline:
                raise subprocess.TimeoutExpired('owned supervisor', timeout)
            time.sleep(.01)
        if self._supervisor is not None:
            remaining = max(0, deadline - time.monotonic()) if deadline is not None else None
            self._supervisor.wait(timeout=remaining)
        return self.returncode

    def receipt(self):
        return read_receipt(self.directory, 'stopped', identity=self.identity)


class SupervisorNotStarted(ValueError):
    """A preflight rejection before either supervisor or child was spawned."""


def _disk_usage(resource_budget):
    if resource_budget is None:
        return None
    if (not isinstance(resource_budget, dict)
            or type(resource_budget.get('max_bytes')) is not int
            or resource_budget['max_bytes'] <= 0
            or not isinstance(resource_budget.get('roots'), list)
            or not resource_budget['roots']):
        raise ValueError('SUPERVISOR_DISK_BUDGET_INVALID')
    total = 0; seen = set()
    for raw in resource_budget['roots']:
        if not isinstance(raw, str) or not Path(raw).is_absolute():
            raise ValueError('SUPERVISOR_DISK_ROOT_INVALID')
        root = Path(raw)
        if any(item.is_symlink() for item in (root, *root.parents)):
            raise ValueError('SUPERVISOR_DISK_ROOT_SYMLINK')
        if not root.exists():
            continue
        pending = [root]
        while pending:
            path = pending.pop()
            try:
                info = path.lstat()
            except FileNotFoundError:
                continue
            identity = (info.st_dev, info.st_ino)
            if identity in seen:
                continue
            seen.add(identity)
            if stat.S_ISLNK(info.st_mode):
                raise ValueError('SUPERVISOR_DISK_OUTPUT_SYMLINK')
            if stat.S_ISDIR(info.st_mode):
                pending.extend(path.iterdir())
            elif stat.S_ISREG(info.st_mode):
                total += info.st_size
    return total


def _signal_group(process, signum):
    if os.name == 'nt':
        process.terminate()
        return
    try:
        os.killpg(process.pid, signum)
    except ProcessLookupError:
        pass


def _private_log(path):
    flags = os.O_WRONLY | os.O_CREAT | os.O_APPEND | getattr(os, 'O_NOFOLLOW', 0)
    fd = open_private_file(path, flags)
    return os.fdopen(fd, 'ab', buffering=0)


def launch(command, *, directory, identity, supervisor_executable, env=None, budget_seconds=120, resource_budget=None):
    if not 0 < budget_seconds <= 120: raise ValueError('SUPERVISOR_BUDGET_INVALID')
    if not identity or not all(isinstance(v, (str, int)) for v in identity.values()):
        raise ValueError('SUPERVISOR_IDENTITY_INVALID')
    try:
        used = _disk_usage(resource_budget)
        if used is not None and used > resource_budget['max_bytes']:
            raise ValueError('SUPERVISOR_DISK_BUDGET_EXCEEDED')
    except (OSError, ValueError) as exc:
        raise SupervisorNotStarted(str(exc)) from exc
    directory = Path(directory)
    directory = ensure_private_directory(directory, exist_ok=False)
    key_path = directory / 'receipt.key'
    fd = open_private_file(key_path)
    with os.fdopen(fd, 'wb') as stream: stream.write(secrets.token_bytes(32))
    spec = {'command': list(command), 'identity': dict(identity), 'env': dict(env or os.environ),
            'budget_seconds': budget_seconds, 'resource_budget': resource_budget}
    _atomic(directory / 'intent.json', spec)
    with _private_log(directory / 'supervisor.stdout.log') as output, \
            _private_log(directory / 'supervisor.stderr.log') as errors:
        process = subprocess.Popen([str(supervisor_executable), str(Path(__file__).resolve()),
                                    '--supervise', str(directory)], stdin=subprocess.DEVNULL,
                                   stdout=output, stderr=errors, start_new_session=os.name != 'nt',
                                   creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
    threading.Thread(target=process.wait, daemon=True).start()
    # The caller must retain its reservation on an ambiguous launch exception.
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        if read_receipt(directory, 'started', identity=identity):
            return OwnedProcessHandle(directory, identity, supervisor=process)
        if process.poll() is not None:
            raise RuntimeError('SUPERVISOR_START_FAILED_OR_UNKNOWN')
        time.sleep(.01)
    raise RuntimeError('SUPERVISOR_START_UNKNOWN')


def supervise(directory):
    directory = Path(directory); spec = _read(directory / 'intent.json')
    with _private_log(directory / 'child.stdout.log') as output, \
            _private_log(directory / 'child.stderr.log') as errors:
        if os.name == 'nt':
            process = WindowsJobProcess(spec['command'], env=spec['env'], stdout=output, stderr=errors)
        else:
            process = subprocess.Popen(spec['command'], env=spec['env'], stdin=subprocess.DEVNULL,
                                       stdout=output, stderr=errors, start_new_session=True)
    try:
        return _supervise_owned(directory, spec, process)
    finally:
        if os.name == 'nt':
            process.close()


def _supervise_owned(directory, spec, process):
    identity = spec['identity']
    start = {'schema': SCHEMA, 'event': 'started', 'identity': identity, 'pid': process.pid,
             'execution_protocol': 1,
             'argv_sha256': hashlib.sha256(_canonical(spec['command'])).hexdigest(),
             'resource_budget': spec.get('resource_budget'), 'observed_at': time.time(),
             'platform': 'windows' if os.name == 'nt' else 'posix',
             'supervisor_identity': process_identity(os.getpid())}
    if os.name == 'nt':
        start.update(process_birth=process.birth, job=process.job_facts)
    _signed_write(directory, start)
    deadline = time.monotonic() + spec['budget_seconds']; stop_at = None
    stop_reason = None; observed_bytes = None; next_disk_check = 0
    operation = None; operation_deadline = None; descendant_result_unobserved = False
    log_roots = [str((directory / name).resolve()) for name in (
        'child.stdout.log', 'child.stderr.log', 'supervisor.stdout.log', 'supervisor.stderr.log')]
    log_budget = {'roots': log_roots, 'max_bytes': MAX_LOG_BYTES}
    budget = spec.get('resource_budget')
    if budget is not None:
        # Diagnostics are task output even when their private directory is
        # outside the caller's output roots. Inode accounting avoids doubles.
        budget = {**budget, 'roots': list(budget['roots']) + log_roots}
    while True:
        code = process.poll()
        if os.name == 'nt':
            active = process.active_processes()
            if active is None:
                return 2
            if code is not None and active == 0:
                break
            if code is not None:
                descendant_result_unobserved = True
        elif code is not None:
            # The owned parent can exit before its same-group children finish.
            # Keep the existing cancellation and budget supervision active until
            # the whole group is observed absent; a live group is not stopped.
            try:
                os.killpg(process.pid, 0)
            except ProcessLookupError:
                break
            except PermissionError:
                return 2
            descendant_result_unobserved = True
        cancel_path = directory / 'cancel.json'
        cancelled = cancel_path.exists() and _read(cancel_path).get('identity') == identity
        now = time.monotonic()
        operation_path = directory / 'operation-budget.json'
        if operation_path.exists():
            try:
                offered = read_receipt(directory, "operation-budget", identity=identity)
                if operation is not None:
                    finished = read_receipt(directory, 'operation-finished-' + operation['token'], identity=identity)
                    if (finished is not None and finished.get('operation_id') == operation['operation_id']
                            and finished.get('token') == operation['token']
                            and finished.get('host_identity') == operation['host_identity']
                            and finished.get('pid') == process.pid and finished.get('finished') is True):
                        operation = None; operation_deadline = None
                valid = (offered.get('identity') == identity and offered.get('pid') == process.pid
                         and offered.get('host_identity', {}).get('pid') == process.pid
                         and offered.get('host_identity', {}).get('task_id') == identity.get('task_id')
                         and offered.get('host_identity', {}).get('launch_nonce') == identity.get('launch_nonce')
                         and isinstance(offered.get('operation_id'), str) and bool(offered['operation_id'])
                         and isinstance(offered.get('token'), str) and bool(offered['token'])
                         and type(offered.get('budget_seconds')) in (int, float)
                         and 0 < offered['budget_seconds'] <= 120
                         and type(offered.get('started_at_epoch')) in (int, float))
                if valid:
                    if operation is None and offered.get('finished') is not True:
                        operation = offered
                        remaining = max(0, min(offered['budget_seconds'],
                            offered['started_at_epoch'] + offered['budget_seconds'] - time.time()))
                        operation_deadline = now + remaining
                        _signed_write(directory, {
                            'schema': SCHEMA, 'event': 'operation-budget-observed',
                            'identity': identity, 'pid': process.pid,
                            'operation_id': offered['operation_id'], 'token': offered['token'],
                            'host_identity': offered['host_identity'],
                            'budget_seconds': offered['budget_seconds'],
                            'started_at_epoch': offered['started_at_epoch'],
                            'observed_at': time.time(),
                        })
                    elif (operation is not None and offered.get('token') == operation['token']
                          and offered.get('operation_id') == operation['operation_id']
                          and offered.get('host_identity') == operation['host_identity']):
                        if offered.get('finished') is True:
                            operation = None; operation_deadline = None
                        # The first observed deadline is immutable; rewriting
                        # budget/start or deleting the file cannot extend it.
            except (OSError, ValueError, KeyError, TypeError):
                stop_reason = stop_reason or 'OPERATION_BUDGET_UNOBSERVABLE'
        operation_cancel = directory / 'operation-cancel.json'
        if operation is not None and operation_cancel.exists():
            try:
                request = _read(operation_cancel)
                if (request.get('identity') == identity and request.get('pid') == process.pid
                        and request.get('operation_id') == operation['operation_id']
                        and request.get('token') == operation['token']
                        and request.get('host_identity') == operation['host_identity']):
                    stop_reason = stop_reason or 'OPERATION_CANCEL_REQUESTED'
            except (OSError, ValueError):
                pass
        if operation_deadline is not None and now >= operation_deadline:
            stop_reason = stop_reason or 'OPERATION_TIME_BUDGET_EXCEEDED'
        if now >= next_disk_check and stop_at is None:
            try:
                if _disk_usage(log_budget) > MAX_LOG_BYTES:
                    stop_reason = 'LOG_BUDGET_EXCEEDED'
                if budget is not None:
                    observed_bytes = _disk_usage(budget)
                    if observed_bytes > budget['max_bytes']:
                        stop_reason = 'DISK_BUDGET_EXCEEDED'
            except (OSError, ValueError):
                stop_reason = 'DISK_BUDGET_UNOBSERVABLE'
            next_disk_check = now + .05
        if cancelled:
            stop_reason = stop_reason or 'CANCEL_REQUESTED'
        if now >= deadline:
            stop_reason = stop_reason or 'TIME_BUDGET_EXCEEDED'
        if stop_reason is not None and stop_at is None:
            _signal_group(process, signal.SIGTERM); stop_at = now
        if stop_at is not None and now - stop_at >= 2:
            if os.name == 'nt':
                process.kill()
            else:
                _signal_group(process, signal.SIGKILL)
        time.sleep(.01)
    code = process.wait()
    facts = {}
    if os.name == 'nt':
        if process.active_processes() != 0:
            return 2
        facts = {'platform': 'windows', 'process_birth': process.birth, 'job': process.job_facts,
                 'child_wait_observed': True, 'job_active_processes': 0}
    else:
        try:
            os.killpg(process.pid, 0)
            return 2
        except ProcessLookupError:
            pass
        except PermissionError:
            return 2
    supervisor_code = 2 if descendant_result_unobserved or (stop_reason is not None and code == 0) else 0
    execution_result = ('failed' if stop_reason is not None or code != 0 else
                        'unknown' if descendant_result_unobserved else 'succeeded')
    _signed_write(directory, {**facts, 'schema': SCHEMA, 'event': 'stopped', 'identity': identity,
                  'pid': process.pid, 'exit_code': code, 'observed_by': 'owned_child_wait',
                  'execution_protocol': 1, 'supervisor_exit_code': supervisor_code,
                  'execution_result': execution_result,
                  'descendant_result_unobserved': descendant_result_unobserved,
                  'stop_reason': stop_reason, 'observed_bytes': observed_bytes, 'operation': operation,
                  'observed_at': time.time(), 'started_sha256': hashlib.sha256(_canonical(start)).hexdigest()})
    return supervisor_code

if __name__ == '__main__':
    if len(sys.argv) != 3 or sys.argv[1] != '--supervise': raise SystemExit(2)
    raise SystemExit(supervise(sys.argv[2]))

"""Bounded producer facts emitted by the Houdini addon, not acceptance verdicts."""
from __future__ import annotations

import hashlib
import json
import re
from typing import Any

SCHEMA = "bridge.houdini.producer-operation/1.0"
COMMAND_KINDS = {
    "scene.create_task_root": "build",
    "node.create": "build",
    "node.create_batch": "build",
    "node.connect": "build",
    "node.set_parm": "edit",
    "node.set_parms": "edit",
    "node.children": "inspect",
    "node.info": "inspect",
    "node.parms": "inspect",
    "node.cook": "cook",
    "agent.fx.build_preview": "build",
    "scene.info": "inspect",
    "agent.fx.apply_candidate": "edit",
    "scene.save_hip": "save",
}


def canonical_sha256(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()


def operation_receipt_sha256(record: dict[str, Any]) -> str:
    return canonical_sha256({key: value for key, value in record.items()
                             if key != "operation_receipt_sha256"})


def validate_operation_receipt(record: dict[str, Any], *, require_completed: bool = True) -> None:
    """Validate integrity and bindings; consumers must still verify current bytes/owner."""
    if (not isinstance(record, dict) or record.get("schema") != SCHEMA
            or record.get("command") not in COMMAND_KINDS
            or record.get("kind") != COMMAND_KINDS[record["command"]]
            or record.get("stage") != record.get("kind")
            or record.get("state") not in {"INTENT", "COMPLETED", "FAILED"}
            or (require_completed and record["state"] != "COMPLETED")):
        raise ValueError("PRODUCER_RECEIPT_INVALID: schema, command or state")
    for name in ("task_id", "operation_id", "request_id"):
        if not isinstance(record.get(name), str) or not record[name]:
            raise ValueError("PRODUCER_RECEIPT_INVALID: " + name)
    for name in ("operation_id", "request_id"):
        if not re.fullmatch(r"[A-Za-z0-9_.-]{1,100}", record[name]):
            raise ValueError("PRODUCER_RECEIPT_INVALID: bounded " + name)
    identity = record.get("host_identity")
    if (not isinstance(identity, dict) or identity.get("task_id") != record["task_id"]
            or type(identity.get("pid")) is not int or identity["pid"] <= 0
            or type(identity.get("scene_epoch")) is not int or identity["scene_epoch"] < 0
            or any(not identity.get(name) for name in
                   ("session_id", "launch_nonce", "process_generation", "plugin_build"))):
        raise ValueError("PRODUCER_RECEIPT_INVALID: owned host identity")
    if record.get("operation_receipt_sha256") != operation_receipt_sha256(record):
        raise ValueError("PRODUCER_RECEIPT_INVALID: receipt digest")
    request = record.get("request")
    if (not isinstance(request, dict)
            or record.get("request_sha256") != canonical_sha256(
                {"task_id": record["task_id"], "command": record["command"],
                 "request_id": record["request_id"], "request": request})
            or request.get("task_id") != record["task_id"]
            or request.get("operation_id") != record["operation_id"]
            or request.get("request_id", record["operation_id"]) != record["request_id"]
            or not isinstance(record.get("frozen_input_manifest"), list)
            or record["frozen_input_manifest"] != request.get("frozen_input_manifest")
            or record.get("frozen_inputs_sha256") != canonical_sha256(record["frozen_input_manifest"])):
        raise ValueError("PRODUCER_RECEIPT_INVALID: frozen request or input digest")
    for name in ("before_scene", "after_scene"):
        if name not in record and name == "after_scene" and record["state"] != "COMPLETED":
            continue
        scene = record.get(name)
        if not isinstance(scene, dict) or scene.get("host_identity") != identity:
            raise ValueError("PRODUCER_RECEIPT_INVALID: scene identity")
        contract = scene.get("scene_contract")
        if contract is None and name == "before_scene" and record["kind"] == "build":
            continue
        if (not isinstance(contract, dict) or contract.get("task_id") != record["task_id"]
                or contract.get("schema") != "houdini.task_scene_contract/2.0"
                or not contract.get("nodes")
                or scene.get("scene_contract_sha256") != canonical_sha256(contract)):
            raise ValueError("PRODUCER_RECEIPT_INVALID: scene contract")
    if record["state"] == "COMPLETED":
        facts = record.get("facts")
        if (not isinstance(facts, dict) or facts.get("scope") != record["kind"]
                or not isinstance(record.get("result"), dict)
                or facts.get("handler_result_sha256") != canonical_sha256(record["result"])):
            raise ValueError("PRODUCER_RECEIPT_INVALID: handler facts")
        if record["kind"] == "save":
            saved = facts.get("saved_scene")
            if (not isinstance(saved, dict) or not saved.get("path") or not saved.get("snapshot_path")
                    or not re.fullmatch(r"[0-9a-f]{64}", str(saved.get("sha256") or ""))
                    or saved.get("sha256") != saved.get("snapshot_sha256")
                    or saved.get("sha256") != record["after_scene"].get("hip_sha256")
                    or saved.get("path") != record["after_scene"].get("hip_path")):
                raise ValueError("PRODUCER_RECEIPT_INVALID: saved bytes")
